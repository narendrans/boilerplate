boilerplate
===========

Boiler plate code for creating single page web applications
